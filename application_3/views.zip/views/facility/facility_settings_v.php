	<div id="left_content">
		<fieldset>
		<legend>Actions</legend>
		<div class="activity edit">
	    <a href="<?php echo site_url('stock_management/get_facility_stock_details');?>"><h2>Edit stock details</h2>	</a>
		</div>
		</fieldset>
	</div>